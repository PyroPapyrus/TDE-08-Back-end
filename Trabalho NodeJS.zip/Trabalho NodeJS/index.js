const express = require("express")
const { rotiador } = require("./routes/to-do-list")

const server = express()
server.use(express.json())

server.use("/api",rotiador)


// http://127.0.0.1:5000 ou http://localhost:5000

server.get("/", (req, res) => {
    res.send("Olá Mundo")
})

server.get("/health",(req,res) => {
    res.json({
        status : "running"
    })
})


const port = 5000
server.listen(port, () => {
    console.log(`Servidor na porta ${port} está em funcionamento`)
})