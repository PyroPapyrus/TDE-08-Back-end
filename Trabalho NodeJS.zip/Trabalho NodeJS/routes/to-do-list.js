const express = require("express")
const {prisma} = require("../db/prisma")
const rotiador = express.Router()

let tasks = [
    {
        id: 1,
        name: "fazer compras",
        description: "realizar compras do mês",
        isDone: false
    }, {
        id: 2,
        name: "limpar a casa",
        description: "realizar a limpeza da casa",
        isDone: false
    }
] 


rotiador.get("/tasks",async (req,res) => {
    const tasks = await prisma.tasks.findMany({
        where: {
            id: req.query.id ? Number(req.query.id) : undefined
        }
    })
    res.json(tasks)
})

rotiador.post("/tasks",async (req,res) => {
    const data = req.body
    const task = await prisma.tasks.create({
        data:  {
            name: data.name,
            description: data.description,
            isDone: Boolean(data.isDone)
        }
    })
    res.status(201).json(task)
})

rotiador.put("/tasks/:id",async (req,res) => {
    const id = Number(req.params.id)
    const task = await prisma.tasks.update({
        data: {
            name: req.body.name,
            description: req.body.description,
            isDone: Boolean(req.body.isDone)
        }, where: {
            id
        }
    })
        res.json(task)
    })

rotiador.delete("/tasks/:id",async (req,res) => {
    const id = Number(req.params.id)
    await prisma.tasks.delete({
        where: {
            id
        }
    })
    res.status(204).send()
})

module.exports = {
    rotiador
}
